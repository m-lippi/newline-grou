// Recursive inclusion
//=include recursive/recursive-one.js

// Above should be b.js and c.js
