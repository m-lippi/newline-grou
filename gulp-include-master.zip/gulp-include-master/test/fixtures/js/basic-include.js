// basic-include.js
/*= include   deep_path/b.js */
// = include   "deep_path/deeper_path/c.js"
