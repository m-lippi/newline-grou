// options-extensions.js
//=include deep_path/b.js
/*
  //=include deep_path/text.txt
/*