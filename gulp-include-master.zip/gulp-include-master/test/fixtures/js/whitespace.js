// whitespace.js
           //=     include deep_path/b.js
    //=      include deep_path/deeper_path/c.js

//=include whitespace/a.js
    // Should be indented below
    //=include whitespace/a.js