// this is a.js
//=require b.js