// recursive-relative.js
//= include a.js
//= include ./../deep_path/b.js
//= include ./../deep_path/deeper_path/c.js
//= include ./deeper/recursive-relative-two.js