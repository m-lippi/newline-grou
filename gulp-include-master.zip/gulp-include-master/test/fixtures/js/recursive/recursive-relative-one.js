// recursive-relative-one.js
//= include ./deeper/recursive-relative-two.js
//= include ./../deep_path/b.js
//= include ./../deep_path/deeper_path/c.js