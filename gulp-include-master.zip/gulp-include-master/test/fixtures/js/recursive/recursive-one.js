// recursive-one.js
//= include ../deep_path/b.js
//= include ../deep_path/deeper_path/c.js
//= include deeper/recursive-two.js