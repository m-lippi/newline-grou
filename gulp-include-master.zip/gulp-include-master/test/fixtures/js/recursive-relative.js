// Recursive relative inclusion
//=include a.js
//=include recursive-relative-one.js