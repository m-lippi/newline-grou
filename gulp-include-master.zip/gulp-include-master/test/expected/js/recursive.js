// Recursive inclusion
// recursive-one.js
// b.js
// c.js
// recursive-two.js
// recursive-three.js

// Above should be b.js and c.js
