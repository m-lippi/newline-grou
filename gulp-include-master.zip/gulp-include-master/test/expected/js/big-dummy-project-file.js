/*
  This is a big dummy project file to test out lots of features of gulp-include
  working together in harmony.
*/

/*
  I'm going to be crazy and import some files inline here in a list.
    // b.js
    // c.js
    //=require deep_path/b.js
    //=require deep_path/deeper_path/c.js
    // b.js
    // c.js
    //=require deep_path/b.js
    //=require deep_path/deeper_path/c.js
    // b.js
    // c.js
    #=require deep_path/b.js
    #=require deep_path/deeper_path/c.js
*/

// This is an inline comment
// Tree inclusion
// b.js
// c.js
