// whitespace.js
           // b.js
    // c.js

  // 2 spaces over
    // 4 spaces over
    
// No spaces over
        // 8 spaces over
    // Should be indented below
      // 2 spaces over
        // 4 spaces over
        
    // No spaces over
            // 8 spaces over