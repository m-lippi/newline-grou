// this is a.js
// this is b.js