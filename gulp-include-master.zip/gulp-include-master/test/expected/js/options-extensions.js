// options-extensions.js
//=include deep_path/b.js
/*
  Lorem ipsum
/*