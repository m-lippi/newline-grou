// Recursive relative inclusion
// include-path a.js
// recursive-relative-one.js
// recursive-relative-two.js
// recursive-three.js
// b.js
// c.js